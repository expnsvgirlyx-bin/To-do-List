-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 12, 2023 at 05:17 PM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latihan_ukk_spp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `pLogin` (IN `username1` VARCHAR(100), IN `password1` VARCHAR(100))  SELECT * FROM tbl_petugas WHERE username = username1 AND password = password1$$$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPembayaranDelete` (IN `a1` INT)  DELETE FROM pembayaran WHERE id_pembayaran =a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPembayaranSimpan` (IN `a1` INT, IN `a2` VARCHAR(255), IN `a3` INT)  INSERT INTO tbl_spp(id_pembayaran, tahun, nominal) VALUES(a1,a2,a3)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPembayaranUpdate` (IN `a1` VARCHAR(255), IN `a2` INT, IN `a3` INT)  UPDATE pembayaran SET tahun=a1, nominal=a2 WHERE id_pembayaran = a3$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPenggunaDelete` (IN `id` INT)  DELETE FROM pengguna WHERE id_pengguna =id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPenggunaSimpan` (IN `a1` VARCHAR(100), IN `a2` VARCHAR(100), IN `a3` VARCHAR(100), IN `a4` ENUM('admin','petugas'))  INSERT INTO pengguna(username, password,  level) VALUES(a1, a2, a3)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPetugasUpdate` (IN `a1` VARCHAR(150), IN `a2` VARCHAR(150), IN `a3` VARCHAR(150), IN `a4` ENUM('admin','petugas'), IN `a5` INT)  UPDATE tbl_petugas SET nama_petugas=a1, username=a2, password=a3, level=a4 WHERE id_petugas = a5$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pTransaksi` ()  SELECT * FROM transaksi INNER JOIN tb_siswa ON tbl_pembayaran.nisn=tb_siswa.nisn INNER JOIN tbl_kelas ON siswa.id_kelas=kelas.id_kelas INNER JOIN pembayaran ON transaksi.id_pembayaran=pembayaran.id_pembayaran INNER JOIN pengguna ON transaksi.id_pengguna=pengguna.id_pengguna$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPengggunaUpdate` (IN `a1` VARCHAR(200), IN `a2` VARCHAR(200), IN `a3` VARCHAR(200), IN `a4` ENUM('admin','petugas'), IN `a5` INT)  UPDATE pengguna SET  username=a1, password=a2, level=a3 WHERE id_pengguna = a4$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPengguna` ()  SELECT * FROM pengguna$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPenggunaDelete` (IN `a1` INT)  DELETE FROM pengguna WHERE pengguna = a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPenggunaEdit` (IN `a1` INT)  SELECT * FROM pengguna WHERE pengguna= a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPenggunaSimpan` (IN `a1` INT, IN `a2` VARCHAR(200), IN `a3` VARCHAR(200), IN `a4` VARCHAR(200), IN `a5` ENUM('admin','petugas'))  INSERT INTO pengguna(id_petugas, username, password, level) VALUES(a1, a2, a3, a4)$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id_kelas` int(11) NOT NULL,
  `nama` varchar(10) NOT NULL,
  `kompetensi_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `tahun_ajaran` varchar(9) NOT NULL,
  `nominal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(128) NOT NULL,
  `role` enum('admin','petugas','siswa','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `username`, `password`, `role`) VALUES
(1, 'admin', '123', 'admin'),
(2, 'petugas', 'petu1', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `id_pengguna` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nisn` varchar(10) NOT NULL,
  `nis` varchar(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `telepon` varchar(14) NOT NULL,
  `total_bayar` int(11) NOT NULL,
  `id_kelas` int(11) NOT NULL,
  `id_pengguna` int(11) NOT NULL,
  `id_pembayaran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `nisn` varchar(15) NOT NULL,
  `tgl_bayar` datetime NOT NULL,
  `bln_dibayar` int(2) NOT NULL,
  `thn_dibayar` int(4) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_petugas` int(11) NOT NULL,
  `id_pembayaran` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `transaksi`
--
DELIMITER $$
CREATE TRIGGER `tBayar` AFTER INSERT ON `transaksi` FOR EACH ROW UPDATE siswa SET total_bayar = total_bayar + new.jumlah_bayar WHERE nisn = new.nisn
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tEdit` BEFORE UPDATE ON `transaksi` FOR EACH ROW UPDATE siswa SET total_bayar = total_bayar - old.jumlah_bayar + new.jumlah_bayar WHERE nisn = new.nisn
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tHapus` BEFORE DELETE ON `transaksi` FOR EACH ROW UPDATE siswa SET total_bayar = total_bayar - old.jumlah_bayar WHERE nisn= old.nisn
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`),
  ADD KEY `nis` (`nis`,`id_kelas`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `nisn` (`nisn`,`id_petugas`,`id_pembayaran`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id_kelas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`id_kelas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
