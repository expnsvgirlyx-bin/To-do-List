<?php
include "koneksi.php";
$id_spp = $_GET['id_spp'];

$sql = "DELETE FROM tbl_spp WHERE id_spp ='$id_spp'";
mysqli_query($koneksi, $sql);
header("location:spp.php");


 ?>