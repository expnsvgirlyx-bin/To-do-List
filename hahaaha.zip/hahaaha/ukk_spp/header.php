<?php 
//header adalah sidebar
session_start();
$nama = $_SESSION['nama'];
$level = $_SESSION['level'];
$nisnSession = $_SESSION['nisn'];
?>
<!DOCTYPE html>
<html>
<head>
	<title><?= $judul; ?></title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="shortcut icon" href="img/logo.png" />
	
	<!-- CSS -->
	<link rel="stylesheet" href="css/bootstrap-4_4_1.min.css"/>
	<link rel="stylesheet" href="css/dataTables.bootstrap4.min.css" />
	
	<!-- JS -->
	<script src="js/jquery-3_4_1.min.js"></script>
	<script src="js/bootstrap-4_4_1.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap4.min.js"></script>
	<script src="js/fontawesome-5_7_2.js"></script>
	<script src="js/simple.money.format.js"></script>
	<script src="js/style.js"></script>



</head>
<body>
	<div class="container">
		<div class="row mt-5">
			<div class="col-3">
				<div class="accordion shadow" id="accordionExample">
					
					<div class="card bgMenu hoverMenu">
						<div class="card-header">
							<h2 class="mb-0">
								<a href="dashboard.php" class="btn btn-link btn-block text-left">DASBOARD</a>
							</h2>
						</div>
					</div>

					<?php 
					if($level=="admin"){?>

						<div class="card">
							<div class="card-header hoverMenu" id="headingTwo">
								<h2 class="mb-0">
									<button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo">
										DATA
									</button>
								</h2>
							</div>

							<div id="collapseTwo" class="collapse show" data-parent="#accordionExample">
								<div class="card-body">
									<div class="menuData"><i class=""></i> <a href="petugas.php">Data Petugas</a></div>
									<div class="menuData"><i class=""></i> <a href="spp.php">Data SPP</a></div>
									<div class="menuData"><i class=""></i> <a href="kelas.php">Data Kelas</a> </div>
									<div class="menuData"><i class=""></i> <a href="siswa.php">Data Siswa</a> </div>
									<div class="menuData"><i class=""></i> <a href="pengguna.php">Data Pengguna</a> </div>
								</div>
							</div>
						</div>
						<?php 
					} ?>

					<?php 
					if($level!="siswa"){?>
						<div class="card">
							<div class="card-header hoverMenu">
								<h2 class="mb-0">
									<a href="pembayaran.php" class="btn btn-link btn-block text-left">PEMBAYARAN</a>
								</h2>
							</div>
						</div>
						<?php 
					} ?>

					<div class="card">
						<div class="card-header" id="headingThree">
							<h2 class="mb-0">
								<button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									LAPORAN
								</button>
							</h2>
						</div>

						<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body">
								<?php
								if($level=="admin"){?>
									<div class="menuData"><i class=""></i> <a href="laporan-laporan.php?nolap=1" target="_blank">Lap. Data Petugas</a></div>
									<div class="menuData"><i class=""></i> <a href="laporan-laporan.php?nolap=2" target="_blank">Lap. Data SPP</a></div>
									<div class="menuData"><i class=""></i> <a href="laporan-laporan.php?nolap=3" target="_blank">Lap. Data Kelas</a></div>
									<div class="menuData"><i class=""></i> <a href="laporan-laporan.php?nolap=4" target="_blank">Lap. Data Siswa</a></div>
									<?php 
								} ?>
								<div class="menuData"><i class=""></i> <a href="history.php" target="_blank">History..</a></div>
							</div>
						</div>
					</div>

					<div class="card bgMenu">
						<div class="card-header">
							<h2 class="mb-0">
								<a href="logout.php" class="btn btn-link btn-block text-left">LOG OUT</a>
							</h2>
						</div>
					</div>
				</div>
			</div>
