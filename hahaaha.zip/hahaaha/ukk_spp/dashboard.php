<?php 
//dalam sidebar berarti sebelah sidebar
$judul = "H O M E";
include "header.php";
include "koneksi.php";
?>

<div class="col-8">
	<div class="container">
		<?php 
		if ($level!="siswa"){?>
			<div class="row mb-3">
				<div class="col">
					<div class="jumbotron p-3 m-0 shadow">
						<h1 class="display-5">Selamat Datang <?= $nama; ?></h1>
						<p class="lead">di Aplikasi Pembayaran SPP</p>
						<hr class="my-4">
						<video controls autoplay>
                        <source src="movie.mp4" type="video/mp4">
						</video>
					</div>
				</div>
			</div>

							
			<div class="row">
				<div class="col p-0 m-0">
					<?php
					$sql 	= "SELECT * FROM tbl_pembayaran a INNER JOIN tb_siswa b ON a.nisn=b.nisn INNER JOIN tbl_kelas c ON b.id_kelas=c.id_kelas ORDER BY a.id_pembayaran";
					$query 	= mysqli_query($koneksi, $sql);
					$data 	= mysqli_fetch_array($query);
					$tgl 		= $data['tgl_bayar'];
					$nama 	= $data['nama'];
					$nama_kelas = $data['nama_kelas'];
					$jumlah_bayar = number_format($data['jumlah_bayar']);
					$ket 	 	= "Tanggal : ". $tgl." - Nama : ".$nama ." - Kelas : " . $nama_kelas . ' - Jumlah bayar Rp. '. $jumlah_bayar;
					?>
						
		</div>
			</div>
			<?php 
		}else{?>
			<div class="row mb-3">
				<div class="col">
					<div class="jumbotron p-3 m-0 shadow">
						<h1 class="display-5">Selamat Datang <?= $nama; ?></h1>
						<p class="lead">di Aplikasi Pembayaran SPP</p>

						<div class="card my-4 d-flex align-items-center border-0 bg-transparent">
							<div class="row">
							<div class="col-md-5 d-flex align-items-center pr-0">
							<img src="" alt="" class="img-thumbnail ml-1">
		                    </div>
								<div class="col-md-7">
									<div class="card-body p-0 mr-1">
										<h5 class="card-title pt-2 text-center">TOTAL PEMBAYARAN</h5>
										<?php 
										$sql 	= "SELECT sum(jumlah_bayar) as jml FROM tbl_pembayaran WHERE nisn = '$nisnSession'";
										$query 	= mysqli_query($koneksi, $sql);
										$data 	= mysqli_fetch_array($query);
										$jml 		= $data['jml'];
										?>
										<p class="card-text display-4 text-center text-danger"><?= number_format($jml);  ?></p>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			</div>
			<?php 
		}?>
	</div>
</div>

</div>
</div>
