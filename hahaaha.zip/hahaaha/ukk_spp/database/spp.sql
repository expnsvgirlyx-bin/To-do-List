-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2022 at 08:29 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `pLogin` (IN `username1` VARCHAR(100), IN `password1` VARCHAR(100))  SELECT * FROM tbl_petugas WHERE username = username1 AND password = password1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPembayaran` ()  SELECT * FROM tbl_pembayaran INNER JOIN tb_siswa ON tbl_pembayaran.nisn=tb_siswa.nisn INNER JOIN tbl_kelas ON tb_siswa.id_kelas=tbl_kelas.id_kelas INNER JOIN tbl_spp ON tbl_pembayaran.id_spp=tbl_spp.id_spp INNER JOIN tbl_petugas ON tbl_pembayaran.id_petugas=tbl_petugas.id_petugas$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPetugasDelete` (IN `id` INT)  DELETE FROM tbl_petugas WHERE id_petugas =id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPetugasSimpan` (IN `a1` VARCHAR(100), IN `a2` VARCHAR(100), IN `a3` VARCHAR(100), IN `a4` ENUM('admin','petugas'))  INSERT INTO tbl_petugas(username, password, nama_petugas, level) VALUES(a1, a2, a3, a4)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pPetugasUpdate` (IN `a1` VARCHAR(150), IN `a2` VARCHAR(150), IN `a3` VARCHAR(150), IN `a4` ENUM('admin','petugas'), IN `a5` INT)  UPDATE tbl_petugas SET nama_petugas=a1, username=a2, password=a3, level=a4 WHERE id_petugas = a5$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pSppDelete` (IN `a1` INT)  DELETE FROM tbl_spp WHERE id_spp =a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pSppSimpan` (IN `a1` INT, IN `a2` VARCHAR(255), IN `a3` INT)  INSERT INTO tbl_spp(id_spp, tahun, nominal) VALUES(a1,a2,a3)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `pSppUpdate` (IN `a1` VARCHAR(255), IN `a2` INT, IN `a3` INT)  UPDATE tbl_spp SET tahun=a1, nominal=a2 WHERE id_spp = a3$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPetugas` ()  SELECT * FROM tbl_petugas$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPetugasDelete` (IN `a1` INT)  DELETE FROM tbl_petugas WHERE id_petugas = a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPetugasEdit` (IN `a1` INT)  SELECT * FROM tbl_petugas WHERE id_petugas= a1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPetugasSimpan` (IN `a1` INT, IN `a2` VARCHAR(200), IN `a3` VARCHAR(200), IN `a4` VARCHAR(200), IN `a5` ENUM('admin','petugas'))  INSERT INTO tbl_petugas(id_petugas, username, password, nama_petugas, level) VALUES(a1, a2, a3, a4, a5)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spPetugasUpdate` (IN `a1` VARCHAR(200), IN `a2` VARCHAR(200), IN `a3` VARCHAR(200), IN `a4` ENUM('admin','petugas'), IN `a5` INT)  UPDATE tbl_petugas SET nama_petugas=a1, username=a2, password=a3, level=a4 WHERE id_petugas = a5$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kelas`
--

CREATE TABLE `tbl_kelas` (
  `id_kelas` int(3) NOT NULL,
  `nama_kelas` varchar(15) DEFAULT NULL,
  `wali_kelas` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kelas`
--

INSERT INTO `tbl_kelas` (`id_kelas`, `nama_kelas`, `wali_kelas`) VALUES
(1, 'RPL-XIIA', 'Ibu Della'),
(2, 'RPL-XIIB', 'Ibu Kartika'),
(3, 'RPL-XIIC', 'Bapak Wowo');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pembayaran`
--

CREATE TABLE `tbl_pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `nisn` varchar(15) DEFAULT NULL,
  `tgl_bayar` date DEFAULT NULL,
  `bulan_bayar` varchar(2) DEFAULT NULL,
  `jumlah_bayar` int(11) DEFAULT NULL,
  `id_petugas` int(11) DEFAULT NULL,
  `id_spp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pembayaran`
--

INSERT INTO `tbl_pembayaran` (`id_pembayaran`, `nisn`, `tgl_bayar`, `bulan_bayar`, `jumlah_bayar`, `id_petugas`, `id_spp`) VALUES
(54, '11806733', '2021-04-11', '01', 200000, 1, 91),
(57, '123456', '2021-05-15', '03', 250000, 1, 91),
(58, '11806733', '2021-05-15', '01', 40000, 14, 91),
(60, '11806733', '2021-05-15', '01', 200000, 14, 90);

--
-- Triggers `tbl_pembayaran`
--
DELIMITER $$
CREATE TRIGGER `tBayar` AFTER INSERT ON `tbl_pembayaran` FOR EACH ROW UPDATE tb_siswa SET total_bayar = total_bayar + new.jumlah_bayar WHERE nisn = new.nisn
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tEdit` BEFORE UPDATE ON `tbl_pembayaran` FOR EACH ROW UPDATE tb_siswa SET total_bayar = total_bayar - old.jumlah_bayar + new.jumlah_bayar WHERE nisn = new.nisn
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tHapus` BEFORE DELETE ON `tbl_pembayaran` FOR EACH ROW UPDATE tb_siswa SET total_bayar = total_bayar - old.jumlah_bayar WHERE nisn= old.nisn
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_petugas`
--

CREATE TABLE `tbl_petugas` (
  `id_petugas` int(11) NOT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `nama_petugas` varchar(45) DEFAULT NULL,
  `level` enum('admin','petugas') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_petugas`
--

INSERT INTO `tbl_petugas` (`id_petugas`, `username`, `password`, `nama_petugas`, `level`) VALUES
(1, 'admin', 'admin', 'Admin', 'admin'),
(14, 'petugas', 'petugas', 'Petugas', 'petugas');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_spp`
--

CREATE TABLE `tbl_spp` (
  `id_spp` int(11) NOT NULL,
  `tahun` int(3) DEFAULT NULL,
  `nominal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_spp`
--

INSERT INTO `tbl_spp` (`id_spp`, `tahun`, `nominal`) VALUES
(90, 2019, 200000),
(91, 2020, 250000),
(93, 2021, 300000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `nisn` varchar(15) NOT NULL,
  `nis` varchar(15) DEFAULT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `id_kelas` int(3) DEFAULT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `kompetensi_keahlian` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `no_telepon` varchar(12) DEFAULT NULL,
  `total_bayar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`nisn`, `nis`, `nama`, `id_kelas`, `jenis_kelamin`, `kompetensi_keahlian`, `alamat`, `no_telepon`, `total_bayar`) VALUES
('11806733', '11806733', 'Mirnawati', 3, 'Laki-laki', 'RPL', 'Jakarta', '08888', 440000),
('123456', '123456', 'Febry', 2, 'Laki-laki', 'RPL', 'Bandung', '081', 250000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kelas`
--
ALTER TABLE `tbl_kelas`
  ADD PRIMARY KEY (`id_kelas`);

--
-- Indexes for table `tbl_pembayaran`
--
ALTER TABLE `tbl_pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `nisn` (`nisn`,`id_petugas`),
  ADD KEY `id_spp` (`id_spp`),
  ADD KEY `id_petugas` (`id_petugas`);

--
-- Indexes for table `tbl_petugas`
--
ALTER TABLE `tbl_petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- Indexes for table `tbl_spp`
--
ALTER TABLE `tbl_spp`
  ADD PRIMARY KEY (`id_spp`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`nisn`),
  ADD UNIQUE KEY `nis` (`nis`),
  ADD KEY `id_kelas` (`id_kelas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_kelas`
--
ALTER TABLE `tbl_kelas`
  MODIFY `id_kelas` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_pembayaran`
--
ALTER TABLE `tbl_pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tbl_petugas`
--
ALTER TABLE `tbl_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_spp`
--
ALTER TABLE `tbl_spp`
  MODIFY `id_spp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_pembayaran`
--
ALTER TABLE `tbl_pembayaran`
  ADD CONSTRAINT `tbl_pembayaran_ibfk_1` FOREIGN KEY (`id_petugas`) REFERENCES `tbl_petugas` (`id_petugas`),
  ADD CONSTRAINT `tbl_pembayaran_ibfk_3` FOREIGN KEY (`nisn`) REFERENCES `tb_siswa` (`nisn`),
  ADD CONSTRAINT `tbl_pembayaran_ibfk_4` FOREIGN KEY (`id_spp`) REFERENCES `tbl_spp` (`id_spp`);

--
-- Constraints for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD CONSTRAINT `tb_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `tbl_kelas` (`id_kelas`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
