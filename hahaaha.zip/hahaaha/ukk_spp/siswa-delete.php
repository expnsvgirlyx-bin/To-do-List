<?php
include "koneksi.php";
$nisn = $_GET['nisn'];

$sql = "DELETE FROM tb_siswa WHERE nisn ='$nisn'";
mysqli_query($koneksi, $sql);
header("location:siswa.php");
?>