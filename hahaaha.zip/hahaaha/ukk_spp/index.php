<!-- <?php
include "koneksi.php";

?> -->
<!DOCTYPE html>
<html lang="en">
<head>
	<title>LOGIN FORM</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Aplikasi SPP">
	<link rel="stylesheet" href="css/bootstrap-4_4_1.min.css">
	<link rel="stylesheet" href="css/style_login.css">
</head>
<body>
	<div class="kotak">
		<form class="form-signin" action="proses.php" method="post" >
	 		<div style="margin-left:50px;margin-top:-5px;font-size:25px; margin-bottom:25px;">Selamat datang!</div>
	 		<div class="input-group mb-0 px-3">
				<div class="input-group-prepend">
				</div>
				<input type="text" id="username" name="username" class="form-control form-control-sm" placeholder="Username" autocomplete="off" autofocus="on" required>
			</div>
			<div class="input-group mb-1 px-3">
				<div class="input-group-prepend">
					
				</div>
				<input type="password" id="password" name="password" class="form-control form-control-sm" placeholder="Password" autocomplete="off" required>
			</div>
			<button class="btn btn-sm btn-primary ml-3 center" type="submit"> Login </button>
		</form>
		</div>
	<script src="js/fontawesome-5_7_2.js"></script>
	</body>
</html>